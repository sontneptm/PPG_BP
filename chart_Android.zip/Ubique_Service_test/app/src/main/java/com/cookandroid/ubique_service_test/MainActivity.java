package com.cookandroid.ubique_service_test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public MyService myService;
    public boolean isService = false;
    public MakeJson makeJson = new MakeJson();
    TextView textView;

    BroadcastReceiver broadcastReceiver;
    ArrayList<Integer> rec_array;
    ArrayList<Integer> rec_array_bp;
    private LineChart chart;
    ArrayList<Entry> values;

    LineDataSet set1;
    int count;
    Thread thread;

    TextView sysText, diasText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        broadcastReceiver = new MainActivityReciever();   //리시버 생성
        serviceBind(MainActivity.this, true); //서비스 바인드

        chart = findViewById(R.id.lineChart);

        sysText = findViewById(R.id.sys);
        diasText = findViewById(R.id.dias);

        chart.setDrawGridBackground(true);
        chart.setBackgroundColor(Color.rgb(255,255,255));
        chart.setGridBackgroundColor(Color.rgb(255,255,255));
        // scaling and dragging and touch (false-비활성화)
        chart.setTouchEnabled(false);
        chart.setDragEnabled(false);
        chart.setScaleEnabled(false);


        //초기 데이터 입력
        values = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            float val = (float) (Math.random() * 10);
            values.add(new Entry(i, val));
        }

        set1 = new LineDataSet(values, "DataSet 1");

        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(set1); // add the data sets

        // create a data object with the data sets
        LineData data = new LineData(dataSets);



        // black lines and points
        set1.setColor(Color.rgb(189,189,189));
        set1.setCircleColor(Color.rgb(189,189,189));
        set1.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set1.setDrawCircles(false);
        set1.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set1.setCubicIntensity(0.2f);
        set1.setDrawFilled(true);
        set1.setDrawHorizontalHighlightIndicator(false);
        set1.setAxisDependency(YAxis.AxisDependency.LEFT);
        set1.setColor(ColorTemplate.getHoloBlue());
        set1.setLineWidth(2.5f);
        set1.setDrawCircles(false);
        set1.setDrawValues(true);
        set1.setValueTextSize(15);
        set1.setValueTextColor(Color.BLACK);
        set1.setFillAlpha(50);
        set1.setFillColor(Color.LTGRAY);
        set1.setFillColor(ColorTemplate.getHoloBlue());
        set1.setHighLightColor(Color.RED);
        set1.setHighlightLineWidth(1.0f);
        set1.setDrawCircleHole(false);

        //chart.moveViewTo(data.getEntryCount(), 50f, YAxis.AxisDependency.LEFT);
        chart.setData(data);
        chart.setVisibleXRangeMaximum(10);

        count = 10;
        chart.invalidate();

    }

    private void addEntry(ArrayList<Integer> next_data_input) {
        LineData data = chart.getData();
        if (data == null) {
            data = new LineData();
            chart.setData(data);
        }

        ILineDataSet set = data.getDataSetByIndex(0);
        // set.addEntry(...); // can be called as well

        if (set == null) {
            set = createSet();
            data.addDataSet(set);
        }

        for(Integer arr : next_data_input){
            data.addEntry(new Entry((float) set.getEntryCount(), (float)((int)arr)), 0);
        }


        data.notifyDataChanged();

        // let the chart know it's data has changed
        chart.notifyDataSetChanged();

        chart.setVisibleXRangeMaximum(200);
        // this automatically refreshes the chart (calls invalidate())
        chart.moveViewTo(data.getEntryCount(), 50f, YAxis.AxisDependency.LEFT);
    }


    public class AddRunnable implements Runnable{
        ArrayList<Integer> next_data = new ArrayList<>();
        public AddRunnable(ArrayList<Integer> next_ont){
            next_data = next_ont;

        }

        @Override
        public void run() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    addEntry(next_data);
                }
            });
        }
    }

    //ppg 값 입력하면 한칸 뒤로 밀려나고 다음 그래프가 그려짐
    public void start_add(ArrayList<Integer> next_num) {
        if (thread != null)
            thread.interrupt();

        thread = new Thread(new AddRunnable(next_num));
        thread.start();
    }


    private LineDataSet createSet() {
        LineDataSet set = new LineDataSet(null, "Real-time Line Data");
//        set.setCubicIntensity(1f);
//        set.setDrawValues(false);
//        set.setValueTextColor(Color.WHITE);
//        set.setColor(Color.WHITE);
//        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
//        set.setDrawCircles(false);
//        set.setHighLightColor(Color.rgb(61, 183, 204));
//        set.setDrawFilled(true);
//        set.setValueTextSize(15);
//        set.setFillAlpha(50);
//        set.setDrawCircleHole(false);

        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setCubicIntensity(0.2f);
        set.setDrawFilled(true);
        set.setDrawHorizontalHighlightIndicator(false);
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setColor(ColorTemplate.rgb("61, 183, 204"));
        set.setLineWidth(2.5f);
        set.setDrawCircles(false);
        set.setDrawValues(true);
        set.setValueTextSize(15);
        set.setValueTextColor(Color.BLACK);
        set.setFillAlpha(50);
        set.setFillColor(Color.LTGRAY);
        set.setFillColor(ColorTemplate.getHoloBlue());
        set.setHighLightColor(Color.RED);
        set.setHighlightLineWidth(1.0f);
        set.setDrawCircleHole(false);


        return set;
    }

    @Override
   protected void onPause() {
        super.onPause();
        unregisterReceiver(broadcastReceiver);  //언 레지스터 리시버
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(isService){
            unbindService(conn); // 서비스 종료
            isService = false;
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        //필터를 추가하여 수신할 브로드캐스트 종류를 정함
        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("waves");
        theFilter.addAction("bp");
        registerReceiver(broadcastReceiver, theFilter);
    }

    Handler mhandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            if(msg.what == 1) {

                sysText.setText(rec_array_bp.get(0)+"");
                diasText.setText(rec_array_bp.get(1)+"");
            }
            return true;

        }
    });

    public class MainActivityReciever extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent i) {

            String intentAction = i.getAction();
            //String intentType = i.getStringExtra("msg_type");


            if(intentAction == "waves") {

                rec_array = new ArrayList<>();
                rec_array = i.getIntegerArrayListExtra("ArrayList");

                if (!rec_array.isEmpty()) {
                    //(temp);
                    start_add(rec_array);
                }
            }
            if(intentAction == "bp") {
                rec_array_bp = new ArrayList<>();
                rec_array_bp = i.getIntegerArrayListExtra("bp");

                if(!rec_array_bp.isEmpty()) {
                    //(temp);

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            mhandler.sendEmptyMessage(1);
                        }
                    }).start();
                }
            }
        }
    }



    ServiceConnection conn = new ServiceConnection() {
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            // 서비스와 연결되었을 때 호출되는 메서드
            // 서비스 객체를 전역변수로 저장
            MyService.MyBinder mb = (MyService.MyBinder) service;
            myService = mb.getService(); // 서비스가 제공하는 메소드 호출하여
            // 서비스쪽 객체를 전달받을수 있슴
            isService = true;
            //Toast.makeText(getApplicationContext(),"서비스 연결",Toast.LENGTH_LONG).show();
        }
        public void onServiceDisconnected(ComponentName name) {
            // 서비스와 연결이 끊겼을 때 호출되는 메서드
            isService = false;
            //Toast.makeText(getApplicationContext(), "서비스 연결 해제", Toast.LENGTH_LONG).show();
        }
    };
    public void serviceBind(Context contexts, boolean newConnection){
        Intent intent = new Intent(
                contexts, // 현재 화면
                MyService.class); // 다음넘어갈 컴퍼넌트

        if(newConnection){
            bindService(intent, // intent 객체
                    conn, // 서비스와 연결에 대한 정의
                    Context.BIND_AUTO_CREATE);
        }
        else{
            bindService(intent, // intent 객체
                    conn, // 서비스와 연결에 대한 정의
                    Context.BIND_NOT_FOREGROUND);
        }
        //처음 서비스를 시작하는 액티비티에서는 Context.BIND_AUTO_CREATE
        //다른 액티비티에서는 Context.BIND_NOT_FOREGROUND를 주어야합니다.
    }
}
